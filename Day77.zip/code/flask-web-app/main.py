from flask import Flask,render_template,request

local_server=True
app=Flask(__name__)

# / = homepage : localhost  http://127.0.0.1:5000"
# /about = aboutpage : localhost  http://127.0.0.1:5000/about"

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/contact")
def contact():
    return render_template("contact.html")

@app.route("/add")
def add():
    a=1000
    b=2322
    res=a+b
    return f"the sume of {a} and {b} is {res}"






app.run(debug=True)